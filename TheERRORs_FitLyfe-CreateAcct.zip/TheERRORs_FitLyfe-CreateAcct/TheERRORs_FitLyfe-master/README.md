# TheERRORs_FitLyfe
Texas Tech CS4365 Group Term Project_Android Application Development

<a href="https://drive.google.com/drive/folders/11ohA0JCv-CwirJrsPxU0TTlVx_mshA6y?usp=sharing">Google Drive</a>
